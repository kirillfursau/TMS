package by.teachmeskills.robot.legs;

public interface ILeg {
    void step();
    int getPrice();
}
