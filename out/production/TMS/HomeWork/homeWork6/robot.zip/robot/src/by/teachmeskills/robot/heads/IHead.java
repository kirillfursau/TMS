package by.teachmeskills.robot.heads;

public interface IHead {
    void speek();
    int getPrice();
}
