package by.teachmeskills.robot.hands;

public interface IHand {
    void upHand();
    int getPrice();
}
